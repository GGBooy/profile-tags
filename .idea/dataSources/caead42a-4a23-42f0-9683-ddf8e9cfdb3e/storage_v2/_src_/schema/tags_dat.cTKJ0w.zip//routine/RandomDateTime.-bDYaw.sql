create
    definer = root@localhost function RandomDateTime(sd DATETIME, ed DATETIME) returns datetime
BEGIN  
    RETURN DATE_ADD(sd,INTERVAL FLOOR(1+RAND()*((ABS(UNIX_TIMESTAMP(ed)-UNIX_TIMESTAMP(sd)))-1)) SECOND);  
    END;

